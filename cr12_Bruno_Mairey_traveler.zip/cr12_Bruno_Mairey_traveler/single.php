<?php get_header(); ?>
  

<main>
    <div class="jumbotron jumbotron-fluid mb-0" style="background-color: #8AADD7">
     
     <?php if(have_posts()) : ?> <!--  If there are posts available  -->

       <?php while(have_posts()) : the_post(); ?> <!-- if there are posts, iterate the posts in the loop-->
            
        <div class="card-deck" style="position: relative; left: 10vw; width: 80vw;">
                    
                        <div class="card mb-4 text-white text-center teaser hovereffect" style="background-color: #4775B3">
                        <div class="media-querries-image">
                          <?php if(has_post_thumbnail()) : ?>
                          <?php the_post_thumbnail(); ?>
                          <?php endif; ?>
                        </div>
                            <!-- <img src="img/japon2.jpg" class="card-img-top imageheight vh-10" alt="thethingstosee" style="border: 0.02px solid silver;" > -->
                          
                            
                            <div class="card-body">
                                <h5 class="card-title"><?php the_title(); ?></h5>
                                <p class="card-text text-left"><?php the_content(); ?></p>
                                      

              
              </div>
                            <div class="card-footer text-center mt-2 small" style="background-color: #0154A0">Created on: <?php the_time('F j, Y g:i a'); ?> by <?php the_author(); ?></div>
             
        </div>
    </div>

        <?php endwhile; ?><!--end the while loop-->

       <?php else :?> <!-- if no posts are found then: -->

       <p>No posts found</p>
       <?php endif; ?> <!-- end if -->             
                     
                      
                    
          
       

      <div id="comments" style="color: white; display: flex; flex-direction: column; align-items: center">
                  <?php comments_template(); ?>

                </div>
    </div>

</main>



 <?php get_footer(); ?>


